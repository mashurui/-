# logistics-front( 物流管理系统前端 ）

物流管理系统前端项目，基于 Layui-2.3.0，后端项目传送门：https://github.com/anselleeyy/logistics-back

![](https://img.shields.io/badge/Author-AnselLee-blue.svg)
![](https://img.shields.io/badge/LayUI-2.3.0-brightgreen.svg) 
![](https://img.shields.io/badge/Licence-MIT-green.svg)

- 个人博客地址：https://www.ltysyn.cn/?p=173
- csdn 地址：https://blog.csdn.net/ansellyy/article/details/81099922
- 欢迎大家 star 或者 fork
