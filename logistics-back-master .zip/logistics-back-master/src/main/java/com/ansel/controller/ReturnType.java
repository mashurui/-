package com.ansel.controller;

public abstract class ReturnType {
	
	protected final static String SUCCESS = "SUCCESS";
	
	protected final static String ERROR = "ERROR"; 

}
