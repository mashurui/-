package com.ansel.service;

import com.ansel.bean.GoodsReceiptInfo;

public interface IGoodsReceiptService {
	
	public boolean add(GoodsReceiptInfo goodsReceiptInfo);

}
